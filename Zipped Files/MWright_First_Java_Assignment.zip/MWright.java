public class MWright {
    public static void main(String[] args) {
        System.out.println("My name is Malon Wright");
        System.out.println("I am 49 until October");
        System.out.println("My hometown is Oakley, Ca");
    }

}
