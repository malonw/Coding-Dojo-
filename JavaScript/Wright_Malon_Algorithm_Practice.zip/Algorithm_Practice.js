// Problem 1
var testArr = [6,3,5,1,2,4]
var sum = 0;
var tot = 0;
newArr = [];
for(var i = 0; i < testArr.length; i++){
    sum = sum + testArr[i];
    console.log('Num ',testArr[i],', Sum ',sum);
// Problem 2
    tot = i * testArr[i];
    newArr.push(tot);
}
    console.log(newArr);

