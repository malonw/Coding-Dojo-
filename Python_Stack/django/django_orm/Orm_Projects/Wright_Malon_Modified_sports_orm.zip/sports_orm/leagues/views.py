from django.shortcuts import render, redirect
from .models import League, Team, Player

from . import team_maker

def index(request):
	context = {
		"leagues": League.objects.all(),
		"teams": Team.objects.all(),
		"players": Player.objects.all(),
		"baseball":League.objects.filter(sport="Baseball"),
		"women":League.objects.filter(name__contains="Womens'"),
		"hockey":League.objects.filter(sport__contains="Hockey"),
		"conference":League.objects.filter(name__contains="Conference"),
		"ocean":League.objects.filter(name__contains="Atlantic"),
		"not_football":League.objects.exclude(sport__contains="Football"),
		"boys":Team.objects.filter(location__contains="Dallas"),
		"raptors":Team.objects.filter(team_name__contains="Raptors"),
		"cities":Team.objects.filter(location__contains="City"),
		"Tnames":Team.objects.filter(team_name__startswith="T"),
		"alpha":Team.objects.all().order_by("location"),
		"reverse":Team.objects.all().order_by("-location"),
		"tires":Player.objects.filter(last_name__contains="Cooper"),
		"race":Player.objects.filter(first_name__contains="Joshua"),
		"ftires":Player.objects.filter(last_name__contains="Cooper").exclude(first_name__contains="Joshua"),
		"waves":Player.objects.filter(first_name__contains="Alexander") | Player.objects.filter(first_name__contains="Wyatt"),

	}
	return render(request, "leagues/index.html", context)

def make_data(request):
	team_maker.gen_leagues(10)
	team_maker.gen_teams(50)
	team_maker.gen_players(200)

	return redirect("index")