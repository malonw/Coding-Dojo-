from django.apps import AppConfig


class TvShowsConfig(AppConfig):
    name = 'TV_shows'
