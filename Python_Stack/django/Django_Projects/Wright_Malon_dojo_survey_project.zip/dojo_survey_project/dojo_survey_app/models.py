from django.db import models

# class Fav_Lang(models.Model):
#     name = models.CharField(max_length=255)

# class FavDojo(models.Model):
#     name = models.CharField(max_length=255)
    
# class Student(models.Model):
#     name = models.CharField(max_length=255)
#     Dojo = models.OneToOneRel(FavDojo)
#     favorite = models.ManyToManyField(Fav_Lang)
# # Create your models here.
