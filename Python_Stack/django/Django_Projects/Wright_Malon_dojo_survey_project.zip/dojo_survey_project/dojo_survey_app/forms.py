# class CreateSurveyForm(forms.ModelForm):
#     class Meta:
#         model = Survey
#         fields = {"name","FavDojo","Fav_Lang","comments"}
        
#         Fav_Lang = forms.ModelMultipleChoiceField(queryset=Fav_Lang.objects.all(), widget=forms.CheckboxSelectMultiple)
        